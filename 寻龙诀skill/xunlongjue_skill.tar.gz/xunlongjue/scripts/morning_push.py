"""
寻龙诀 · 早盘一进二推送 (v4.1 — 46.0%胜率, ≥5/周, ≤3/日)
Gap>5.5%, VR>0.3, 股价<50, 振幅<12%, 二板非一字板
=============================================
评分: -100 ~ 100，三档: 🔴≥60  🟡0~59  ⚪<0
硬逻辑(12闸) → 通过后进入软逻辑加减分
每个维度有加分区间和减分区间，偏离越大扣越多

维度权重:
  ① 竞价Gap     -20 ~ +25   最优4-5%满分
  ② 市值适配     -15 ~ +20   最优80-120亿满分
  ③ 封板时间     -15 ~ +25   9:25+25, 13:10-15
  ④ 量比         -10 ~ +10   最优1.5-4
  ⑤ 首板开盘     -10 ~ +10   最优0-3%
  ⑥ 换手率        -8 ~ +5    最优3-8%
  ⑦ 封板强度      -5 ~ +5    >2%封板资金/流通+5
  ⑧ 板块共振       0 ~ +5    同行业≥2只
  ⑨ 炸板罚分     -18 ~ 0     >1次-10+时长>10分-8
  ⑩ 大盘系数    ×0.85~1.15  MA5方向+J方向

理论范围: +105 ~ -101 → clamp(-100,100)
"""

import akshare as ak
import pandas as pd
import sqlite3
import requests
import time
import sys
import os
import json
from datetime import datetime, timedelta
from hermes_stock_lib import fetch_thl_kline

DB = '/root/hermes_stock.db'

# 安全上限：防止极端行情（全市场涨停潮）跑飞
MAX_KLINE_FETCH = 30      # 单次最多补30只K线
MAX_AUCTION_FETCH = 30    # 单次最多拉30只竞价
MAX_ANALYZE_STOCKS = 30   # 单次最多分析30只首板

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)

# ═══════════════════════════════════════════
# 数据库工具箱
# ═══════════════════════════════════════════
def ensure_tables():
    db = sqlite3.connect(DB)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS first_boards (
            date TEXT, code TEXT, name TEXT, pct REAL, close REAL,
            amount REAL, total_cap REAL, float_cap REAL, turnover REAL,
            seal_time TEXT, last_seal TEXT, bomb_count INTEGER,
            stat TEXT, industry TEXT, seal_money REAL,
            PRIMARY KEY (date, code)
        );
        CREATE TABLE IF NOT EXISTS auction_snapshots (
            date TEXT, code TEXT, name TEXT,
            open_price REAL, prev_close REAL, price REAL,
            high REAL, low REAL, volume REAL, amount REAL,
            gap REAL, is_limit_up INTEGER, fetched_at TEXT,
            PRIMARY KEY (date, code)
        );
        CREATE TABLE IF NOT EXISTS daily_kline (
            code TEXT, date TEXT,
            open REAL, high REAL, low REAL, close REAL,
            volume REAL, amount REAL, pct REAL,
            prev_close REAL, is_limit_up INTEGER DEFAULT 0,
            gap_open REAL, volume_ratio REAL,
            PRIMARY KEY (code, date)
        );
        CREATE TABLE IF NOT EXISTS daily_screen (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            screen_date TEXT, first_board_date TEXT,
            code TEXT, name TEXT, industry TEXT,
            first_seal_time TEXT, bomb_count INTEGER,
            turnover REAL, amount REAL, seal_money REAL,
            lu_close REAL, next_open REAL, next_gap REAL,
            next_close REAL, next_pct REAL, next_is_lu INTEGER,
            score INTEGER DEFAULT 0, pushed INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS market_index (
            date TEXT, code TEXT, name TEXT,
            open REAL, close REAL, high REAL, low REAL,
            pct REAL, volume REAL, amount REAL,
            ma5 REAL, kdj_k REAL, kdj_d REAL, kdj_j REAL,
            ma10 REAL, ma20 REAL, ma60 REAL,
            macd_dif REAL, macd_dea REAL, macd_bar REAL,
            volume_ma5 REAL,
            PRIMARY KEY (date, code)
        );
        CREATE TABLE IF NOT EXISTS stocks_info (
            code TEXT PRIMARY KEY, name TEXT, industry TEXT,
            total_cap REAL, float_cap REAL,
            first_seen TEXT, last_updated TEXT
        );
    """)
    db.commit()
    db.close()

def db_has(table, date, code=None):
    db = sqlite3.connect(DB)
    if code:
        r = db.execute(f"SELECT 1 FROM {table} WHERE date=? AND code=? LIMIT 1", (date, code)).fetchone()
    else:
        r = db.execute(f"SELECT 1 FROM {table} WHERE date=? LIMIT 1", (date,)).fetchone()
    db.close()
    return r is not None

def db_count(table, date, col='date'):
    db = sqlite3.connect(DB)
    r = db.execute(f"SELECT COUNT(*) FROM {table} WHERE {col}=?", (date,)).fetchone()[0]
    db.close()
    return r

# ═══════════════════════════════════════════
# Step 0: 大盘数据
# ═══════════════════════════════════════════
def fetch_market_index_kline(days=20):
    db = sqlite3.connect(DB)
    existing = db.execute("SELECT COUNT(*) FROM market_index WHERE code='000001'").fetchone()[0]
    if existing >= days:
        log(f"  Step0: market_index 已有 {existing} 天，跳过拉取")
        calc_market_indicators(db)  # 始终重算：afternoon可能插入了无MA5/KDJ的行
        rows = db.execute("SELECT date, close, ma5, kdj_j FROM market_index WHERE code='000001' ORDER BY date DESC LIMIT 3").fetchall()
        db.close()
        return rows
    
    log(f"  Step0: 拉取上证指数K线 (Sina API)...")
    try:
        resp = requests.get(
            "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
            "CN_MarketData.getKLineData?symbol=sh000001&scale=240&ma=no&datalen=30",
            timeout=10
        )
        data = resp.json()
    except Exception as e:
        log(f"  ❌ 上证K线拉取失败: {e}")
        db.close()
        return []
    
    if not data:
        db.close()
        return []
    
    inserted = 0
    for d in data:
        date_str = d['day'].replace('-', '')
        o = float(d['open']); c = float(d['close'])
        h = float(d['high']); l = float(d['low']); v = float(d['volume'])
        prev = db.execute("SELECT close FROM market_index WHERE code='000001' AND date<? ORDER BY date DESC LIMIT 1", (date_str,)).fetchone()
        pct = round((c - prev[0]) / prev[0] * 100, 2) if prev else 0
        db.execute("INSERT OR REPLACE INTO market_index (date,code,name,open,close,high,low,pct,volume,amount) VALUES (?,'000001','上证指数',?,?,?,?,?,?,0)",
                   (date_str, o, c, h, l, pct, v))
        inserted += 1
    db.commit()
    log(f"  Step0: 入库 {inserted} 条上证K线")
    calc_market_indicators(db)
    
    rows = db.execute("SELECT date, close, ma5, kdj_j FROM market_index WHERE code='000001' ORDER BY date DESC LIMIT 3").fetchall()
    db.close()
    return rows

def calc_market_indicators(db):
    """计算上证指数 MA(5/10/20/60) + KDJ + MACD + 量能均线"""
    rows = db.execute("SELECT date, close, high, low, volume FROM market_index WHERE code='000001' ORDER BY date").fetchall()
    n = len(rows)
    if n < 9:
        log(f"  ⚠️ 上证数据不足9天({n})，无法计算KDJ")
    
    dates = [r[0] for r in rows]
    closes = [r[1] for r in rows]
    highs = [r[2] for r in rows]
    lows = [r[3] for r in rows]
    volumes = [r[4] for r in rows]
    
    # MACD 预分配
    ema12 = [None]*n; ema26 = [None]*n
    dif = [None]*n; dea = [None]*n; bar = [None]*n
    
    for i in range(n):
        # MA
        if i >= 4:
            ma5 = round(sum(closes[i-4:i+1])/5, 2)
        else:
            ma5 = None
        if i >= 9:
            ma10 = round(sum(closes[i-9:i+1])/10, 2)
        else:
            ma10 = None
        if i >= 19:
            ma20 = round(sum(closes[i-19:i+1])/20, 2)
        else:
            ma20 = None
        if i >= 59:
            ma60 = round(sum(closes[i-59:i+1])/60, 2)
        else:
            ma60 = None
        
        # 量能均线
        if i >= 4:
            vol_ma5 = round(sum(volumes[i-4:i+1])/5, 2)
        else:
            vol_ma5 = None
        
        # KDJ (9日RSV)
        if i >= 8:
            h9 = max(highs[i-8:i+1]); l9 = min(lows[i-8:i+1])
            rsv = (closes[i]-l9)/(h9-l9)*100 if h9!=l9 else 50
            prev = db.execute("SELECT kdj_k,kdj_d FROM market_index WHERE code='000001' AND date=?", (dates[i-1],)).fetchone()
            if prev and prev[0] is not None:
                k = round(2/3*prev[0] + 1/3*rsv, 2)
                d = round(2/3*prev[1] + 1/3*k, 2)
            else:
                k = d = 50.0
            j = round(3*k - 2*d, 2)
        else:
            k = d = j = None
        
        # MACD: EMA12/EMA26
        if i == 0:
            ema12[i] = closes[i]; ema26[i] = closes[i]
        else:
            ema12[i] = round(closes[i]*2/13 + (ema12[i-1] or closes[i])*11/13, 4)
            ema26[i] = round(closes[i]*2/27 + (ema26[i-1] or closes[i])*25/27, 4)
        
        if ema12[i] and ema26[i]:
            dif[i] = round(ema12[i] - ema26[i], 4)
        
        if i >= 8 and dif[i] is not None:
            if dea[i-1] is not None:
                dea[i] = round(dif[i]*2/10 + dea[i-1]*8/10, 4)
            else:
                dea[i] = round(sum(dif[max(0,i-8):i+1]) / min(i+1,9), 4)
        
        if dif[i] is not None and dea[i] is not None:
            bar[i] = round((dif[i] - dea[i])*2, 4)
        
        db.execute("""UPDATE market_index SET 
            ma5=?, kdj_k=?, kdj_d=?, kdj_j=?,
            ma10=?, ma20=?, ma60=?,
            macd_dif=?, macd_dea=?, macd_bar=?,
            volume_ma5=?
            WHERE code='000001' AND date=?""",
            (ma5,k,d,j, ma10,ma20,ma60, dif[i],dea[i],bar[i], vol_ma5, dates[i]))
    db.commit()

def score_market_outlook(db):
    """
    上证指数四维共振评分 (-100 ~ +100)
    维度1: MA排列   ±30   多头排列+30, 空头排列-30
    维度2: MACD     ±30   金叉红柱+30, 死叉绿柱-30
    维度3: KDJ      ±20   超卖拐头+20, 超买回落-20
    维度4: 量价     ±20   放量阳线+20, 放量阴线-20

    返回: (score, label, coefficient)
      🔥 +60~+100 → 强烈看多, 系数 1.15
      🟢 +20~+60  → 偏多,     系数 1.08
      ⚪ -20~+20  → 震荡,     系数 1.00
      🟡 -60~-20  → 偏空,     系数 0.90
      🔴 -100~-60 → 强烈看空,  系数 0.80
    """
    r = db.execute("""
        SELECT close, ma5, ma10, ma20, ma60,
               macd_dif, macd_dea, macd_bar,
               kdj_k, kdj_d, kdj_j,
               volume, volume_ma5, pct
        FROM market_index WHERE code='000001'
        ORDER BY date DESC LIMIT 2
    """).fetchall()
    
    if len(r) < 2:
        log("  ⚠️ 大盘数据不足2天，默认震荡")
        return 0, "⚪ 震荡", 1.0
    
    today, yesterday = r[0], r[1]
    (c, m5, m10, m20, m60, dif, dea, bar, k, d, j, vol, vma5, pct) = today
    (yc, _, _, _, _, ydif, ydea, ybar, yk, yd, yj, _, _, _) = yesterday
    
    score = 0
    
    # === 维度1: MA排列 (-30 ~ +30) ===
    mas = [v for v in [m5,m10,m20,m60] if v is not None]
    if len(mas) >= 3:
        if m5 and m10 and m5 > m10:
            up_pairs = sum(1 for a,b in [(m5,m10),(m10,m20),(m20,m60)] if a and b and a>b)
            dn_pairs = sum(1 for a,b in [(m5,m10),(m10,m20),(m20,m60)] if a and b and a<b)
            if up_pairs >= 3:
                score += 30
            elif up_pairs == 2:
                score += 15
            elif up_pairs == 1:
                score += 5
            elif dn_pairs >= 3:
                score -= 30
            elif dn_pairs == 2:
                score -= 15
            elif dn_pairs == 1:
                score -= 5
    
    # === 维度2: MACD (-30 ~ +30) ===
    if dif is not None and dea is not None:
        if dif > 0 and dif > dea:      # 多头金叉
            score += 30 if bar and bar > 0 else 20
        elif dif > 0 and dif <= dea:   # 多头回调
            score -= 10
        elif dif < 0 and dif > dea:    # 空头反弹
            score += 10
        elif dif < 0 and dif <= dea:   # 空头死叉
            score -= 30 if bar and bar < 0 else -20
    
    # === 维度3: KDJ (-20 ~ +20) ===
    if j is not None and yj is not None:
        if j < 20 and j > yj:          # 超卖区拐头向上
            score += 20
        elif j < 50 and k and d and k > d:
            score += 10
        elif j > 80 and j < yj:        # 超买区拐头向下
            score -= 20
        elif j > 50 and k and d and k < d:
            score -= 10
    
    # === 维度4: 量价配合 (-20 ~ +20) ===
    if vol and vma5 and vma5 > 0:
        vol_ratio = vol / vma5
        if pct is not None:
            if vol_ratio > 1.2 and pct > 0:
                score += 20  # 放量阳线
            elif vol_ratio > 1.2 and pct < 0:
                score -= 20  # 放量阴线
            elif vol_ratio < 0.8 and pct > 0:
                score += 5   # 缩量阳线
            elif vol_ratio < 0.8 and pct < 0:
                score -= 5   # 缩量阴线
    
    # 钳制 + 五档
    score = max(-100, min(100, score))
    
    if score >= 60:
        label = "🔥 强烈看多"
        coeff = 1.15
    elif score >= 20:
        label = "🔴 偏多"
        coeff = 1.08
    elif score > -20:
        label = "⚪ 震荡"
        coeff = 1.00
    elif score > -60:
        label = "🔵 偏空"
        coeff = 0.90
    else:
        label = "🟢 强烈看空"
        coeff = 0.80
    
    # 诊断明细
    diag_parts = []
    if m5 and m10: diag_parts.append(f"MA5>{'↑' if m5>m10 else '↓'}MA10")
    if dif and dea: diag_parts.append(f"MACD{'金叉' if dif>dea else '死叉'}")
    if j is not None: diag_parts.append(f"J={j:.0f}")
    diag = " ".join(diag_parts)
    
    log(f"  大盘评分: {score:+d} {label} (×{coeff:.2f}) [{diag}]")
    return score, label, coeff

# ═══════════════════════════════════════════
# Step 1: 拉取昨日首板
# ═══════════════════════════════════════════
def fetch_and_save_first_boards(date_str):
    existing = db_count('first_boards', date_str)
    if existing > 0:
        log(f"  Step1: first_boards 已有 {existing} 条，跳过拉取")
        return existing
    
    log(f"  Step1: 拉取 {date_str} 首板...")
    try:
        zt = ak.stock_zt_pool_em(date=date_str)
    except Exception as e:
        log(f"  ❌ akshare拉取失败: {e}")
        return 0
    
    if len(zt) == 0:
        log(f"  ⚠️ {date_str} 非交易日或无涨停数据")
        return 0
    
    db = sqlite3.connect(DB)
    count = 0
    for _, row in zt.iterrows():
        code = str(row['代码']).zfill(6)
        seal_money = row.get('封板资金', 0) or 0
        db.execute("""INSERT OR REPLACE INTO first_boards 
            (date,code,name,pct,close,amount,total_cap,float_cap,turnover,seal_time,last_seal,bomb_count,stat,industry,seal_money)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (date_str, code, row['名称'], row.get('涨跌幅'), row.get('最新价'), row.get('成交额'),
             row.get('总市值'), row.get('流通市值'), row.get('换手率'),
             row.get('首次封板时间'), row.get('最后封板时间'), row.get('炸板次数'),
             row.get('涨停统计'), row.get('所属行业'), seal_money))
        count += 1
    db.commit()
    db.close()
    log(f"  Step1: 入库 {count} 条")
    update_stocks_info(zt)
    return count

def update_stocks_info(zt_df):
    db = sqlite3.connect(DB)
    today = datetime.now().strftime('%Y-%m-%d')
    for _, row in zt_df.iterrows():
        code = str(row['代码']).zfill(6)
        db.execute("""INSERT OR REPLACE INTO stocks_info (code,name,industry,total_cap,float_cap,first_seen,last_updated)
            VALUES (?,?,?,?,?,COALESCE((SELECT first_seen FROM stocks_info WHERE code=?),?),?)""",
            (code, row['名称'], row.get('所属行业'), row.get('总市值'), row.get('流通市值'), code, today, today))
    db.commit()
    db.close()

# ═══════════════════════════════════════════
# Step 2: K线
# ═══════════════════════════════════════════
def ensure_kline_for_stocks(codes, target_date):
    db = sqlite3.connect(DB)
    missing = [c for c in codes if not db_has('daily_kline', target_date, c)]
    db.close()
    
    if not missing:
        log(f"  Step2: daily_kline 全部覆盖 ({len(codes)}只)，跳过")
        return
    
    if len(missing) > MAX_KLINE_FETCH:
        log(f"  Step2: 缺失 {len(missing)} 只，截断至 {MAX_KLINE_FETCH}（安全上限）")
        missing = missing[:MAX_KLINE_FETCH]
    
    log(f"  Step2: 缺失K线 {len(missing)}/{len(codes)} 只，拉取中...")
    fetched = 0
    for i, code in enumerate(missing):
        rows = fetch_thl_kline(code)
        if rows:
            db = sqlite3.connect(DB)
            for r in rows:
                try:
                    db.execute("INSERT OR IGNORE INTO daily_kline (code,date,open,high,low,close,volume,amount,pct,prev_close) VALUES (?,?,?,?,?,?,?,?,?,?)", r)
                except: pass
            db.commit(); db.close()
            fetched += 1
        if (i+1) % 20 == 0: log(f"    [{i+1}/{len(missing)}]")
        time.sleep(0.15)
    
    db = sqlite3.connect(DB)
    for code in missing:
        db.execute("UPDATE daily_kline SET is_limit_up=CASE WHEN pct>=9.8 THEN 1 ELSE 0 END, gap_open=CASE WHEN prev_close>0 THEN (open-prev_close)*100.0/prev_close END WHERE code=?", (code,))
        rows = db.execute("SELECT date,volume FROM daily_kline WHERE code=? ORDER BY date", (code,)).fetchall()
        for idx in range(5, len(rows)):
            prev5_avg = sum(rows[j][1] for j in range(idx-5, idx)) / 5
            if prev5_avg > 0:
                db.execute("UPDATE daily_kline SET volume_ratio=? WHERE code=? AND date=?", (round(rows[idx][1]/prev5_avg,2), code, rows[idx][0]))
    db.commit(); db.close()
    log(f"  Step2: 拉取完成，新增 {fetched} 只K线")


# ═══════════════════════════════════════════
# Step 3: 竞价
# ═══════════════════════════════════════════
def fetch_and_save_auctions(codes, today_str):
    db = sqlite3.connect(DB)
    cached = {}; need_fetch = []
    for c in codes:
        r = db.execute("SELECT open_price,prev_close,price,gap,high,low,volume,amount FROM auction_snapshots WHERE date=? AND code=?", (today_str,c)).fetchone()
        if r:
            cached[c] = {'open':r[0],'prev':r[1],'price':r[2],'gap':r[3],'high':r[4],'low':r[5],'volume':r[6],'amount':r[7]}
        else:
            need_fetch.append(c)
    db.close()
    
    if cached: log(f"  Step3: auction_snapshot 缓存命中 {len(cached)}/{len(codes)}")
    if not need_fetch: return cached
    
    if len(need_fetch) > MAX_AUCTION_FETCH:
        log(f"  Step3: 需拉取 {len(need_fetch)} 只，截断至 {MAX_AUCTION_FETCH}")
        need_fetch = need_fetch[:MAX_AUCTION_FETCH]
    
    log(f"  Step3: 拉取竞价 {len(need_fetch)} 只 (Sina API)...")
    db = sqlite3.connect(DB); now = datetime.now().isoformat()
    for code in need_fetch:
        sid = f"{'sh' if code.startswith('6') else 'sz'}{code}"
        try:
            resp = requests.get(f'https://hq.sinajs.cn/list={sid}', headers={'Referer':'https://finance.sina.com.cn'}, timeout=5)
            data = resp.text.split('"')[1].split(',')
            if len(data) < 10: continue
            open_p = float(data[1]); prev = float(data[2]); price = float(data[3])
            high = float(data[4]); low = float(data[5]); volume = float(data[8]); amount = float(data[9])
            gap = (open_p - prev) / prev * 100
            db.execute("INSERT OR REPLACE INTO auction_snapshots (date,code,name,open_price,prev_close,price,high,low,volume,amount,gap,is_limit_up,fetched_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                       (today_str, code, data[0], open_p, prev, price, high, low, volume, amount, round(gap,2), 0, now))
            cached[code] = {'open':open_p,'prev':prev,'price':price,'gap':round(gap,2),'high':high,'low':low,'volume':volume,'amount':amount}
        except Exception as e: log(f"    {code}: API失败 ({e})")
        time.sleep(0.25)
    db.commit(); db.close()
    log(f"  Step3: 竞价入库 {len(need_fetch)} 条")
    return cached

# ═══════════════════════════════════════════
# 评分核心: 对称加减分体系 (-100 ~ 100)
# ═══════════════════════════════════════════

def linear_score(val, best_lo, best_hi, score_max, bound_lo, bound_hi, score_lo, score_hi):
    """
    通用线性加减分
    best_lo~best_hi: 最优区间 → score_max (最高分)
    bound_lo~best_lo: 偏低减分区 → 线性: score_lo → score_max
    best_hi~bound_hi: 偏高减分区 → 线性: score_max → score_hi
    超出 bound 范围 → 直接取边界分
    """
    if best_lo <= val <= best_hi:
        return score_max
    if val < best_lo:
        if val <= bound_lo: return score_lo
        # 线性插值: bound_lo→score_lo, best_lo→score_max
        return round(score_lo + (val - bound_lo) / (best_lo - bound_lo) * (score_max - score_lo))
    # val > best_hi
    if val >= bound_hi: return score_hi
    return round(score_max + (val - best_hi) / (bound_hi - best_hi) * (score_hi - score_max))


def score_gap(gap_pct):
    """
    ① 竞价Gap: -15 ~ +25 (1082样本回测: Gap越高胜率越高, 单调递增)
    最优: ≥8% → +25 (77%涨停)
    强: 6~8% → +20 (53~62%)
    中: 4~6% → +15 (36~42%)
    弱: 2.85~4% → -5 (18~26%)
    差: <2.85% → -15 (4~13%, 低开必死)
    一字板(>9.5%): 买不到, C2硬逻辑排除
    """
    if gap_pct is None:
        return 0
    g = gap_pct
    if g < 2.85:
        return -15
    if g >= 8.0:
        return 25
    if g >= 6.0:
        return 20
    if g >= 4.0:
        return 15
    # 2.85~4.0: -5 -> +15
    return round(-5 + (g - 2.85) / (4.0 - 2.85) * 20)


def score_market_cap(total_cap):
    """
    ② 市值适配: -15 ~ +20
    最优: 80-120亿 → +20
    60-80 / 120-160 → +8 ~ +20
    45-60 / 160-200 → -15 ~ +8
    """
    cap = total_cap / 1e8
    return linear_score(cap,
                        best_lo=80, best_hi=120, score_max=20,
                        bound_lo=45, bound_hi=200,
                        score_lo=-15, score_hi=-15)


def score_seal_time(seal_time_str):
    """
    ③ 封板时间: -15 ~ +25
    最优: 9:25-9:35 → +25
    9:35-10:00 → +25~+10
    10:00-11:00 → +10~0
    11:00-13:10 → 0~-15
    """
    t = str(seal_time_str).strip()
    if not t or t == '-' or len(t) < 4:
        return -15  # 无封板时间最差
    
    minutes = int(t[:2]) * 60 + int(t[2:4])
    # 定义三个拐点
    p925 = 9*60+25   # 565
    p935 = 9*60+35   # 575
    p1000 = 10*60    # 600
    p1100 = 11*60    # 660
    p1310 = 13*60+10 # 790
    
    if minutes <= p935:
        return 25
    elif minutes <= p1000:
        return round(25 - (minutes - p935) / (p1000 - p935) * 15)
    elif minutes <= p1100:
        return round(10 - (minutes - p1000) / (p1100 - p1000) * 10)
    elif minutes <= p1310:
        return round(0 - (minutes - p1100) / (p1310 - p1100) * 15)
    else:
        return -15


def score_volume_ratio(vr):
    """
    ④ 量比: -10 ~ +10 (1082样本: 缩量涨停29%胜率最优, 温和放量14%反而差)
    最优: <0.8 → +10 (缩量涨停=主力锁仓, 29%一进二)
    中等: 0.8~1.5 → +3 (基准水平)
    偏弱: 1.5~3.0 → -3 (过度关注)
    差: >3.0 → -10 (爆量出货)
    """
    if not vr: return 0
    if vr <= 0.8:
        return 10   # 缩量涨停最优
    if vr <= 1.5:
        return 3    # 基准
    if vr <= 3.0:
        return -3   # 过度关注
    return -10      # 爆量


def score_gap_open(gap_open):
    """
    ⑤ 首板开盘涨幅: -5 ~ +5 (1082样本: 信号弱, 缩权)
    高开(>2%): +5 微加分
    平开(0~2%): 0
    低开(<0%): -5 微扣分
    """
    if gap_open is None: return 0
    if gap_open >= 2: return 5
    if gap_open >= 0: return 0
    return -5


def score_turnover(turnover):
    """
    ⑥ 换手率: -8 ~ +5
    最优: 3-8% → +5
    偏低: 1-3% → -2~+5, <1%→-5
    偏高: 8-15% → +5~-2, >15%→-8
    """
    if turnover is None: return 0
    t = float(turnover)
    if 3 <= t <= 8:
        return 5
    if 1 <= t < 3:
        return round(-2 + (t - 1) / 2 * 7)
    if t < 1:
        return -5
    if 8 < t <= 15:
        return round(5 - (t - 8) / 7 * 7)
    return -8


def score_seal_strength(seal_money, float_cap):
    """
    ⑦ 封板强度: -5 ~ +5
    最优: >2% → +5
    1-2% → +3
    0.3-1% → -2~+3
    <0.3% → -5
    """
    if not seal_money or not float_cap or float_cap == 0:
        return 0
    ratio = seal_money / float_cap
    if ratio >= 0.02:
        return 5
    if ratio >= 0.01:
        return 3
    if ratio >= 0.003:
        return round(-2 + (ratio - 0.003) / 0.007 * 5)
    return -5


def score_bomb_penalty(bomb_count, seal_time_str, last_seal_str):
    """
    ⑨ 炸板罚分: -18 ~ 0
    """
    penalty = 0
    if bomb_count and bomb_count > 1:
        penalty += 10
    try:
        t1 = str(seal_time_str).strip(); t2 = str(last_seal_str).strip()
        if t1 and t2 and t1 != '-' and t2 != '-':
            m1 = int(t1[:2])*60 + int(t1[2:4])
            m2 = int(t2[:2])*60 + int(t2[2:4])
            if m2 - m1 > 10:
                penalty += 8
    except: pass
    return penalty


# ═══════════════════════════════════════════
# ⑩ KDJ反转信号
# ═══════════════════════════════════════════

def calc_kdj_for_stock(code, target_date, db):
    """计算指定股票在指定日期的KDJ(9,3,3)值，返回(k,d,j)或None"""
    rows = db.execute("""
        SELECT date, high, low, close FROM daily_kline 
        WHERE code=? AND date <= ?
        ORDER BY date ASC
    """, (code, target_date)).fetchall()
    
    if len(rows) < 9:
        return None
    
    # 找到目标日在列表中的位置
    target_idx = None
    for i, r in enumerate(rows):
        if r[0] == target_date:
            target_idx = i
            break
    if target_idx is None or target_idx < 8:
        return None
    
    # 迭代计算KDJ（从第9天起，初始K=50,D=50）
    K, D = 50.0, 50.0
    for i in range(8, target_idx + 1):
        window = rows[i-8:i+1]
        high_9 = max(r[1] for r in window)
        low_9 = min(r[2] for r in window)
        close = window[-1][2]
        
        if high_9 == low_9:
            rsv = 50.0
        else:
            rsv = (close - low_9) / (high_9 - low_9) * 100
        
        K = 2/3 * K + 1/3 * rsv
        D = 2/3 * D + 1/3 * K
    
    J = 3 * K - 2 * D
    return (round(K, 1), round(D, 1), round(J, 1))


def score_kdj_reversal(code, first_board_date, db):
    """
    ⑩ KDJ动量: -3 ~ +3 (1082样本: J>D仅+1.2%提升, 信号微弱, 缩权)
    加分侧: J>D +1~3, J上涨 +1~2
    减分侧: J<D -1~3, J下跌 -1~2
    """
    prev_dates = db.execute("""
        SELECT DISTINCT date FROM daily_kline WHERE code=? AND date < ?
        ORDER BY date DESC LIMIT 3
    """, (code, first_board_date)).fetchall()
    
    if len(prev_dates) < 2:
        return 0
    
    prev_date = prev_dates[0][0]
    prev2_date = prev_dates[1][0]
    
    kdj = calc_kdj_for_stock(code, prev_date, db)
    kdj2 = calc_kdj_for_stock(code, prev2_date, db)
    
    if kdj is None or kdj2 is None:
        return 0
    
    _, d, j = kdj
    _, _, j2 = kdj2
    
    score = 0
    diff = d - j      # 负=J>D, 正=J<D
    change = j - j2   # 正=J涨, 负=J跌
    
    # J>D 微加分 / J<D 微扣分
    if diff < -20: score += 3
    elif diff < -10: score += 2
    elif diff < 0: score += 1
    elif diff > 20: score -= 3
    elif diff > 10: score -= 2
    elif diff > 0: score -= 1
    
    # J上涨微加分 / J下跌微扣分
    if change > 10: score += 2
    elif change > 0: score += 1
    elif change < -10: score -= 2
    elif change < 0: score -= 1
    
    return max(-3, min(3, score))


# ═══════════════════════════════════════════
# Step 4: 从库分析
# ═══════════════════════════════════════════
def analyze_from_db(yesterday_str, prev_str, today_str, auctions, market_coeff):
    db = sqlite3.connect(DB)
    
    fb_rows = db.execute("""
        SELECT code,name,pct,close,amount,total_cap,float_cap,
               turnover,seal_time,last_seal,bomb_count,stat,industry,seal_money
        FROM first_boards WHERE date=?
    """, (yesterday_str,)).fetchall()
    
    if not fb_rows:
        log(f"  Step4: 无首板数据")
        db.close()
        return [], [], market_coeff
    
    log(f"  Step4: 分析 {len(fb_rows)} 只首板...")
    
    # 安全上限：极端行情截断
    if len(fb_rows) > MAX_ANALYZE_STOCKS:
        log(f"  Step4: 首板 {len(fb_rows)} 只，截断至 {MAX_ANALYZE_STOCKS}")
        fb_rows = fb_rows[:MAX_ANALYZE_STOCKS]
    
    hard_pass = []
    pushed_codes = set()
    
    for row in fb_rows:
        (code,name,pct,close,amount,total_cap,float_cap,
         turnover,seal_time,last_seal,bomb,stat,industry,seal_money) = row
        
        # ==== 硬逻辑 12闸 ====
        if not seal_time: continue
        t = str(seal_time).strip()
        if not t or t == '-' or len(t) < 4: continue
        if int(t[:2])*60 + int(t[2:4]) > 790: continue  # C5: >13:10
        
        if not amount or amount < 150_000_000: continue    # C8
        if not total_cap or total_cap/1e8 < 45 or total_cap/1e8 > 200: continue  # C11
        if not close or close >= 50: continue               # C12 V4.1: <50 (曾30)
        if not float_cap or float_cap/1e8 <= 43: continue   # C13
        
        r = db.execute("SELECT 1 FROM daily_kline WHERE code=? AND date=? AND is_limit_up=1", (code, prev_str)).fetchone()
        if r: continue  # C9
        
        r = db.execute("SELECT gap_open, volume_ratio, high, low, prev_close FROM daily_kline WHERE code=? AND date=?", (code, yesterday_str)).fetchone()
        if not r: continue
        gap_open_val, vr_val, fb_high, fb_low, fb_prev = r
        
        if gap_open_val is not None and gap_open_val >= 5: continue  # C3
        if not vr_val or vr_val <= 0.3: continue  # C7 V4: >0.3 (was 0.8)
        
        # V4.1: 振幅 < 12% (曾10%)
        if fb_high and fb_low and fb_prev and fb_prev > 0:
            amp = (fb_high - fb_low) / fb_prev * 100
            if amp > 12: continue
        
        ad = auctions.get(code)
        if not ad: continue
        
        gap = ad['gap']
        c1 = gap > 5.5  # V4.1: >5.5% (曾6%)
        c2 = ad['open'] < round(ad['prev'] * 1.1, 2) - 0.01
        
        # ==== 软逻辑加减分 ====
        s_gap = score_gap(gap)
        s_cap = score_market_cap(total_cap)
        s_seal = score_seal_time(seal_time)
        s_vol = score_volume_ratio(vr_val)
        s_open = score_gap_open(gap_open_val)
        
        s_turn = score_turnover(turnover)
        s_strength = score_seal_strength(seal_money, float_cap)
        s_bomb = score_bomb_penalty(bomb, seal_time, last_seal)
        s_kdj = score_kdj_reversal(code, yesterday_str, db)
        
        raw_score = s_gap + s_cap + s_seal + s_vol + s_open + s_turn + s_strength + s_kdj - s_bomb
        
        pct_val = round((ad['price'] - ad['prev']) / ad['prev'] * 100, 2)
        
        result = {
            'code':code,'name':name,'industry':industry or '未知',
            'seal_time':seal_time,'bomb':bomb,
            'amount':amount,'close':close,
            'gap':gap,'price':ad['price'],'prev':ad['prev'],'open':ad['open'],
            'is_lu':1 if pct_val>=9.8 else 0,
            'c1':c1,'c2':c2,'market_cap':round(total_cap/1e8,1),
            's_gap':s_gap,'s_cap':s_cap,'s_seal':s_seal,'s_vol':s_vol,
            's_open':s_open,'s_turn':s_turn,'s_strength':s_strength,'s_bomb':s_bomb,
            's_kdj':s_kdj,'raw_score':raw_score,
            'seal_money':seal_money,'total_cap':total_cap,'float_cap':float_cap,
            'turnover':turnover,
        }
        hard_pass.append(result)
        
        if c1 and c2:
            pushed_codes.add(code)
    
    # ==== 板块共振 ====
    from collections import Counter
    ind_counts = Counter(r['industry'] for r in hard_pass)
    resonance = {ind:5 for ind,cnt in ind_counts.items() if cnt>=2}
    if resonance:
        log(f"  板块共振: {dict(resonance)}")
    
    for r in hard_pass:
        r['resonance'] = resonance.get(r['industry'], 0)
        raw = r['raw_score'] + r['resonance']
        # 钳制在-100~100
        r['score'] = max(-100, min(100, round(raw * market_coeff)))
    
    # 入库
    for r in hard_pass:
        db.execute("""INSERT OR REPLACE INTO daily_screen
            (screen_date,first_board_date,code,name,industry,first_seal_time,bomb_count,amount,seal_money,turnover,lu_close,
             next_open,next_gap,next_close,next_pct,next_is_lu,score,pushed)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (today_str, yesterday_str, r['code'],r['name'],r['industry'],
             r['seal_time'],r['bomb'],r['amount'],r.get('seal_money',0),r.get('turnover',0),
             r['prev'], r['open'],r['gap'],r['price'],
             round((r['price']-r['prev'])/r['prev']*100,2), r['is_lu'],
             r['score'], 1 if r['code'] in pushed_codes else 0))
    
    db.commit(); db.close()
    
    # V4.1: 每日推送上限3只, 按得分排序取Top3
    final = [r for r in hard_pass if r['c1'] and r['c2']]
    final.sort(key=lambda x: x.get('score', 0), reverse=True)
    final = final[:3]
    
    log(f"  Step4: 分析完成 → {len(hard_pass)}候选 → {len(final)}推送")
    return hard_pass, final, market_coeff

# ═══════════════════════════════════════════
# Step 5: 推送
# ═══════════════════════════════════════════
def format_push(final_list, total_cand, market_coeff, market_label="⚪ 震荡", market_score=0):
    today_str = datetime.now().strftime('%m/%d')
    
    if not final_list:
        return f"🐉 寻龙诀 · {today_str} 早盘\n\n⚠️ 今日无一进二信号\n{total_cand}只候选无一通过竞价\n大盘: {market_label}\n\n宁错过，不做错。"
    
    sorted_list = sorted(final_list, key=lambda x: x['score'], reverse=True)
    
    lines = [f"🐉 寻龙诀 · {today_str} 早盘推送", "",
             f"{market_label} 大盘评分{market_score:+d} | ×{market_coeff:.2f} | 候选{total_cand} → 推送{len(sorted_list)}",
             "━━━━━━━━━━━━━━━━━━━━"]
    
    for i, r in enumerate(sorted_list, 1):
        score = r['score']
        if score >= 60:
            tag = "🔴"
        elif score >= 0:
            tag = "🟡"
        else:
            tag = "⚪"
        
        # 评分条 (可视化: ■=正 □=负)
        bar_len = max(0, min(10, score // 10)) if score >= 0 else 0
        bar = "■" * bar_len + "□" * (10 - bar_len)
        
        lines.append(f"{tag} {i}. {r['code']} {r['name']}  [{bar}] {score:+d}分")
        lines.append(f"   Gap {r['gap']:+.2f}%  市值{r['market_cap']}亿  {r['industry']}")
        
        # 各维度加减分明细
        dims = []
        for k, label in [('s_gap','Gap'),('s_cap','市值'),('s_seal','封板'),('s_vol','量比'),('s_open','开盘'),('s_turn','换手'),('s_strength','封强'),('s_kdj','KDJ')]:
            v = r.get(k, 0)
            dims.append(f"{label}{v:+d}")
        if r.get('resonance'): dims.append(f"共振+{r['resonance']}")
        if r.get('s_bomb'): dims.append(f"炸板-{r['s_bomb']}")
        lines.append("   " + " ".join(dims))
    
    lines += ["━━━━━━━━━━━━━━━━━━━━",
              f"🔴≥60  🟡0~59  ⚪<0  负分=弱不推",
              f"推送 {len(sorted_list)} 只 | 大盘系数 ×{market_coeff:.2f}",
              "⚠️ 仅供研究 · 不构成投资建议"]
    
    return '\n'.join(lines)

# ═══════════════════════════════════════════
# Main
# ═══════════════════════════════════════════
def main():
    ensure_tables()
    
    today = datetime.now()
    today_str = today.strftime('%Y%m%d')
    weekday = today.weekday()
    if weekday >= 5:
        log("周末不交易")
        return
    
    if weekday == 0:
        yesterday = today - timedelta(3)
        prev_day = today - timedelta(4)
    else:
        yesterday = today - timedelta(1)
        prev_day = today - timedelta(2)
    
    y_str = yesterday.strftime('%Y%m%d')
    p_str = prev_day.strftime('%Y%m%d')
    
    log(f"🐉 寻龙诀 v2.2 对称加减分")
    log(f"今日:{today_str} 昨首板:{y_str} 前日:{p_str}")
    log("═" * 50)
    
    fetch_market_index_kline(20)
    db = sqlite3.connect(DB)
    market_score, market_label, market_coeff = score_market_outlook(db)
    db.close()
    
    count = fetch_and_save_first_boards(y_str)
    if count == 0:
        print("无首板数据")
        return
    
    db = sqlite3.connect(DB)
    codes = [r[0] for r in db.execute("SELECT code FROM first_boards WHERE date=?", (y_str,)).fetchall()]
    db.close()
    ensure_kline_for_stocks(codes, y_str)
    
    auctions = fetch_and_save_auctions(codes, today_str)
    
    all_results, final, coeff = analyze_from_db(y_str, p_str, today_str, auctions, market_coeff)
    
    msg = format_push(final, len(all_results), coeff, market_label, market_score)
    print("\n" + msg)
    
    db = sqlite3.connect(DB)
    stats = {
        'first_boards': db_count('first_boards', y_str),
        'auctions': db_count('auction_snapshots', today_str),
        'daily_screen': db_count('daily_screen', today_str, 'screen_date'),
    }
    db.close()
    log(f"\n📊 入库: first_boards={stats['first_boards']} auctions={stats['auctions']} screen={stats['daily_screen']}")
    log(f"📊 大盘系数: ×{coeff:.2f}")

if __name__ == '__main__':
    main()
