#!/usr/bin/env python3
"""寻龙诀 数据库初始化"""
import sqlite3, os
DB = os.environ.get('HERMES_STOCK_DB', '/root/hermes_stock.db')
def init():
    db = sqlite3.connect(DB)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS daily_kline (code TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, amount REAL, pct REAL, prev_close REAL, is_limit_up INTEGER DEFAULT 0, gap_open REAL, volume_ratio REAL, PRIMARY KEY (code, date));
        CREATE TABLE IF NOT EXISTS first_boards (date TEXT, code TEXT, name TEXT, pct REAL, close REAL, amount REAL, total_cap REAL, float_cap REAL, turnover REAL, seal_time TEXT, last_seal TEXT, bomb_count INTEGER, stat TEXT, industry TEXT, seal_money REAL, PRIMARY KEY (date, code));
        CREATE TABLE IF NOT EXISTS auction_snapshots (date TEXT, code TEXT, name TEXT, open_price REAL, prev_close REAL, price REAL, high REAL, low REAL, volume REAL, amount REAL, gap REAL, is_limit_up INTEGER, fetched_at TEXT, PRIMARY KEY (date, code));
        CREATE TABLE IF NOT EXISTS daily_screen (id INTEGER PRIMARY KEY AUTOINCREMENT, screen_date TEXT, first_board_date TEXT, code TEXT, name TEXT, industry TEXT, first_seal_time TEXT, bomb_count INTEGER, turnover REAL, amount REAL, seal_money REAL, lu_close REAL, next_open REAL, next_gap REAL, next_close REAL, next_pct REAL, next_is_lu INTEGER, score INTEGER, pushed INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS daily_review (review_date TEXT PRIMARY KEY, total_first_boards INTEGER, candidates_filtered INTEGER, pushed INTEGER, hit_limit_up INTEGER, hit_rate REAL, market_pct REAL, market_trend TEXT, best_code TEXT, best_gap REAL, notes TEXT);
        CREATE TABLE IF NOT EXISTS market_index (date TEXT, code TEXT, name TEXT, open REAL, close REAL, high REAL, low REAL, pct REAL, volume REAL, amount REAL, ma5 REAL, kdj_k REAL, kdj_d REAL, kdj_j REAL, PRIMARY KEY (date, code));
        CREATE TABLE IF NOT EXISTS stocks_info (code TEXT PRIMARY KEY, name TEXT, industry TEXT, total_cap REAL, float_cap REAL, first_seen TEXT, last_updated TEXT);
    """)
    db.commit(); db.close()
    print(f"✅ 数据库初始化完成: {DB}")
if __name__ == '__main__': init()
