"""
寻龙诀共享函数库
=================
供 morning_push.py 和 afternoon_review.py 共用。
避免 fetch_thl_kline 在两处重复定义导致版本漂移。
"""
import requests

def fetch_thl_kline(code, target_date=None):
    """从同花顺API拉取单只股票K线，可选过滤日期。
    返回: [(code, date, open, high, low, close, volume, amount, pct, prev_close), ...]
    """
    try:
        resp = requests.get(f"http://d.10jqka.com.cn/v2/line/hs_{code}/01/last.js", timeout=10)
        text = resp.text
        start = text.find('"data":"') + 8
        end = text.find('"', start)
        if start < 8 or end < 0:
            return None
        data_str = text[start:end]
        rows = []
        for line in data_str.split(';'):
            parts = line.split(',')
            if len(parts) < 8:
                continue
            try:
                d = parts[0]
                if target_date and d != target_date:
                    continue
                o = float(parts[1])
                h = float(parts[2])
                l = float(parts[3])
                c = float(parts[4])
                v = float(parts[5])
                amt = float(parts[6])
                pct = float(parts[7]) if parts[7] else 0
                rows.append((code, d, o, h, l, c, v, amt, pct, None))
            except Exception:
                continue
        return rows
    except Exception:
        return None
