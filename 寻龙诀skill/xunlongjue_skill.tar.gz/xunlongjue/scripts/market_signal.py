"""
寻龙诀 · 次日大盘信号预测 v3
==============================
每天15:20收盘后运行，用当日收盘数据预测下一个交易日。
MA5(±3) + KDJ(±3) + MACD(±4) + MA10趋势中和(±2)
"""

import sqlite3
import requests
from datetime import datetime, timedelta

DB = '/root/hermes_stock.db'

def calc_market_indicators(db):
    """确保今日指标已计算。已有则跳过拉取，只重算。"""
    today_str = datetime.now().strftime('%Y%m%d')
    
    # 检查今天数据是否已在库中（morning_push 9:26已拉过）
    existing = db.execute(
        "SELECT 1 FROM market_index WHERE code='000001' AND date=? AND kdj_j IS NOT NULL",
        (today_str,)
    ).fetchone()
    
    if existing:
        # 数据已有（morning_push已拉），跳过拉取
        pass
    else:
        # 缺失才拉取（首日运行或异常情况）
        try:
            resp = requests.get(
                "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
                "CN_MarketData.getKLineData?symbol=sh000001&scale=240&ma=no&datalen=5",
                timeout=10
            )
            data = resp.json()
            for d in data[-3:]:
                date_str = d['day'].replace('-', '')
                o = float(d['open']); c = float(d['close'])
                h = float(d['high']); l = float(d['low']); v = float(d['volume'])
                prev = db.execute("SELECT close FROM market_index WHERE code='000001' AND date<? ORDER BY date DESC LIMIT 1", (date_str,)).fetchone()
                pct = round((c - prev[0]) / prev[0] * 100, 2) if prev else 0
                db.execute("INSERT OR REPLACE INTO market_index (date,code,name,open,close,high,low,pct,volume,amount) VALUES (?,'000001','上证指数',?,?,?,?,?,?,0)",
                           (date_str, o, c, h, l, pct, v))
            db.commit()
        except Exception as e:
            print(f"  ⚠️ 拉取K线失败: {e}")
    
    # 重算全部指标
    rows = db.execute("SELECT date,close,high,low,volume FROM market_index WHERE code='000001' ORDER BY date").fetchall()
    n = len(rows)
    dates = [r[0] for r in rows]; closes = [r[1] for r in rows]
    highs = [r[2] for r in rows]; lows = [r[3] for r in rows]
    volumes = [r[4] for r in rows]
    
    ema12=[None]*n; ema26=[None]*n; dif=[None]*n; dea=[None]*n; bar=[None]*n
    
    for i in range(n):
        if i>=4: ma5=round(sum(closes[i-4:i+1])/5,2)
        else: ma5=None
        if i>=9: ma10=round(sum(closes[i-9:i+1])/10,2)
        else: ma10=None
        if i>=4: vma5=round(sum(volumes[i-4:i+1])/5,2)
        else: vma5=None
        
        if i>=8:
            h9=max(highs[i-8:i+1]); l9=min(lows[i-8:i+1])
            rsv=(closes[i]-l9)/(h9-l9)*100 if h9!=l9 else 50
            prev_kd=db.execute("SELECT kdj_k,kdj_d FROM market_index WHERE code='000001' AND date=?",(dates[i-1],)).fetchone()
            if prev_kd and prev_kd[0] is not None:
                k=round(2/3*prev_kd[0]+1/3*rsv,2); d=round(2/3*prev_kd[1]+1/3*k,2)
            else: k=d=50.0
            j=round(3*k-2*d,2)
        else: k=d=j=None
        
        if i==0: ema12[i]=closes[i]; ema26[i]=closes[i]
        else:
            ema12[i]=round(closes[i]*2/13+(ema12[i-1] or closes[i])*11/13,4)
            ema26[i]=round(closes[i]*2/27+(ema26[i-1] or closes[i])*25/27,4)
        if ema12[i] and ema26[i]: dif[i]=round(ema12[i]-ema26[i],4)
        if i>=8 and dif[i] is not None:
            if dea[i-1] is not None: dea[i]=round(dif[i]*2/10+dea[i-1]*8/10,4)
            else: dea[i]=round(sum(dif[max(0,i-8):i+1])/min(i+1,9),4)
        if dif[i] and dea[i]: bar[i]=round((dif[i]-dea[i])*2,4)
        
        db.execute("""UPDATE market_index SET 
            ma5=?,ma10=?,kdj_k=?,kdj_d=?,kdj_j=?,
            macd_dif=?,macd_dea=?,macd_bar=?,volume_ma5=?
            WHERE code='000001' AND date=?""",
            (ma5,ma10,k,d,j,dif[i],dea[i],bar[i],vma5,dates[i]))
    db.commit()


def main():
    db = sqlite3.connect(DB)
    
    # 确保今天指标已计算
    calc_market_indicators(db)
    
    # 用今天收盘数据预测次日
    rows = db.execute("""
        SELECT date,close,ma5,ma10,macd_dif,macd_dea,kdj_k,kdj_d,kdj_j,pct
        FROM market_index WHERE code='000001' AND kdj_j IS NOT NULL
        ORDER BY date DESC LIMIT 5
    """).fetchall()
    
    if len(rows) < 5:
        print("⚠️ 数据不足")
        db.close()
        return
    
    r   = rows[0]   # 今天收盘
    rp  = rows[1]   # 昨天
    rpp = rows[2]   # 前天
    
    d,c,ma5,ma10,dif,dea,k,dkd,j,pct = r
    pct = pct or 0
    yma5  = rp[2];  yma5_p = rpp[2]
    yma10 = rp[3]
    yj    = rp[8];  yy_j   = rpp[8]
    ydkd  = rp[7]
    ydif  = rp[4];  yydif  = rpp[4]
    
    score = 0; layers = []
    
    # ═══ MA5 (±3) ═══
    ms = 0; mp = []
    if ma5 > yma5:      ms += 1; mp.append('MA5↑')
    elif ma5 < yma5:    ms -= 1; mp.append('MA5↓')
    if yma5_p:
        if yma5 > yma5_p and ma5 <= yma5:    ms -= 1; mp.append('MA5反转↓')
        elif yma5 < yma5_p and ma5 >= yma5:  ms += 1; mp.append('MA5反转↑')
    if ma5 < yma5 and yma5 > ma10:       ms -= 1; mp.append('MA10上跌')
    elif ma5 > yma5 and yma5 < ma10:     ms += 1; mp.append('MA10下涨')
    score += ms
    layers.append(('MA5', f'{"+".join(mp) if mp else "平"} MA5={ma5:.0f}', ms))
    
    # ═══ KDJ (±3) ═══
    js = 0; jp = []
    if j > yj:      js += 1; jp.append('J涨')
    elif j < yj:    js -= 1; jp.append('J跌')
    if yy_j is not None:
        if yj > yy_j and j <= yj:    js -= 1; jp.append('J反转↓')
        elif yj < yy_j and j >= yj:  js += 1; jp.append('J反转↑')
    if j < yj and yj > ydkd:        js -= 1; jp.append('D上跌')
    elif j > yj and yj < ydkd:      js += 1; jp.append('D下涨')
    score += js
    layers.append(('KDJ', f'{"+".join(jp) if jp else "平"} J={j:.1f} D={dkd:.1f}', js))
    
    # ═══ MACD (±4) ═══
    ms2 = 0; mp2 = []
    if dif > ydif:      ms2 += 1; mp2.append('DIF↑')
    elif dif < ydif:    ms2 -= 1; mp2.append('DIF↓')
    if yydif is not None:
        if ydif > yydif and dif <= ydif:    ms2 -= 1; mp2.append('反转↓')
        elif ydif < yydif and dif >= ydif:  ms2 += 1; mp2.append('反转↑')
    if dif < ydif and ydif > dea:       ms2 -= 1; mp2.append('DEA上跌')
    elif dif > ydif and ydif < dea:     ms2 += 1; mp2.append('DEA下涨')
    if dif < ydif and ydif > 0:         ms2 -= 1; mp2.append('0轴上跌')
    elif dif > ydif and ydif < 0:       ms2 += 1; mp2.append('0轴下涨')
    score += ms2
    layers.append(('MACD', f'{"+".join(mp2) if mp2 else "平"} DIF={dif:.1f} DEA={dea:.1f}', ms2))
    
    # ═══ MA10趋势中和 (±2) ═══
    ns = 0
    if ma10 > yma10:        ns = +2; layers.append(('MA10中和', f'上涨 MA10={ma10:.0f}>{yma10:.0f}', ns))
    elif ma10 < yma10:      ns = -2; layers.append(('MA10中和', f'下跌 MA10={ma10:.0f}<{yma10:.0f}', ns))
    else:                   layers.append(('MA10中和', f'平 MA10={ma10:.0f}', 0))
    score += ns
    
    score = max(-12, min(12, score))
    
    if score >= 5:       label = '🔥强多'; advice = '积极选股，满仓'
    elif score >= 2:     label = '🔴偏多'; advice = '正常选股，满仓'
    elif score <= -5:    label = '🟢强空'; advice = '谨慎防守，半仓/空仓'
    elif score <= -2:    label = '🔵偏空'; advice = '控制仓位，半仓'
    else:                label = '⚪中性'; advice = '正常操作'
    
    # 判断下一个交易日
    today = datetime.now()
    if today.weekday() == 4:  # 周五
        next_day = today + timedelta(3)
    else:
        next_day = today + timedelta(1)
    
    today_str = today.strftime('%m/%d')
    next_str = next_day.strftime('%m/%d')
    
    lines = [
        f"🐉 寻龙诀 · {today_str}收盘 → {next_str}预测",
        "",
        f"{label} 总分{score:+d}  → {advice}",
        "",
        f"📊 今日收盘: 上证{c:.0f}  {pct:+.2f}%",
        f"   MA5={ma5:.0f} MA10={ma10:.0f}  J={j:.1f} D={dkd:.1f}  DIF={dif:.1f} DEA={dea:.1f}",
        "",
        "📐 评分明细:",
    ]
    
    for name, detail, s in layers:
        bar = '+' * s if s > 0 else ('-' * abs(s)) if s < 0 else '0'
        lines.append(f"   {name:<8} {s:+2d} [{bar}]  {detail}")
    
    lines += [
        f"   {'─'*8}",
        f"   总分     {score:+3d}  → {label}",
        "",
        "⚠️ 仅供研究 · 不构成投资建议",
    ]
    
    print('\n'.join(lines))
    db.close()

if __name__ == '__main__':
    main()
