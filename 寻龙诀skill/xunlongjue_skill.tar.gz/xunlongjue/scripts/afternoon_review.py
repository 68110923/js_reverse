"""
寻龙诀 · 收盘复盘 (v1.0 — 入库优先版)
=====================================
原则: 先查库 → 缺则拉 → 入库 → 再分析
复盘也增量，不重复拉已入库数据。

数据流:
  Step0: 检查库中缺失
  Step1: 补拉今日K线 → daily_kline
  Step2: 拉今日涨停池 → first_boards
  Step3: 拉大盘指数 → market_index
  Step4: 更新 daily_screen 收盘数据
  Step5: 生成 daily_review + 推送
"""

import akshare as ak
import sqlite3
import requests
import time
from datetime import datetime, timedelta
from hermes_stock_lib import fetch_thl_kline

DB = '/root/hermes_stock.db'

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)

# ═══════════════════════════ 数据库 ═══════════════════════════
def ensure_tables():
    db = sqlite3.connect(DB)
    db.execute("""
        CREATE TABLE IF NOT EXISTS market_index (
            date TEXT, code TEXT, name TEXT,
            open REAL, close REAL, high REAL, low REAL,
            pct REAL, volume REAL, amount REAL,
            ma5 REAL, kdj_k REAL, kdj_d REAL, kdj_j REAL,
            PRIMARY KEY (date, code)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS daily_review (
            review_date TEXT PRIMARY KEY,
            total_first_boards INTEGER,
            candidates_filtered INTEGER,
            pushed INTEGER,
            hit_limit_up INTEGER,
            hit_rate REAL,
            market_pct REAL,
            market_trend TEXT,
            best_code TEXT,
            best_gap REAL,
            notes TEXT
        )
    """)
    db.commit()
    db.close()

def db_count(table, date, col='date'):
    db = sqlite3.connect(DB)
    r = db.execute(f"SELECT COUNT(*) FROM {table} WHERE {col}=?", (date,)).fetchone()[0]
    db.close()
    return r

# ═══════════════════════════ Step1: 补今日K线 ═══════════════════════════
def ensure_today_kline(today_str, codes):
    """确保指定股票有今日K线，缺则从同花顺拉"""
    existing = db_count('daily_kline', today_str)
    if existing >= len(codes) * 0.9:
        log(f"  Step1: daily_kline 今日已有 {existing} 条，跳过")
        return existing
    
    log(f"  Step1: 补拉今日K线 ({existing}/{len(codes)} 已有)...")
    fetched = 0
    for i, code in enumerate(codes):
        # 检查是否已有
        db = sqlite3.connect(DB)
        has = db.execute("SELECT 1 FROM daily_kline WHERE code=? AND date=?", 
                         (code, today_str)).fetchone()
        db.close()
        if has:
            continue
        
        rows = fetch_thl_kline(code, today_str)
        if rows:
            db = sqlite3.connect(DB)
            for r in rows:
                db.execute("""
                    INSERT OR IGNORE INTO daily_kline 
                    (code, date, open, high, low, close, volume, amount, pct, prev_close)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                """, r)
            db.commit()
            db.close()
            fetched += 1
        
        if (i+1) % 20 == 0:
            log(f"    [{i+1}/{len(codes)}]")
        time.sleep(0.12)
    
    # 衍生字段
    # 衍生字段 (is_limit_up, gap_open, volume_ratio)
    db = sqlite3.connect(DB)
    db.execute(f"""
        UPDATE daily_kline SET 
            is_limit_up = CASE WHEN pct >= 9.8 THEN 1 ELSE 0 END,
            gap_open = CASE WHEN prev_close > 0 THEN (open-prev_close)*100.0/prev_close END
        WHERE date = ?
    """, (today_str,))
    
    # volume_ratio for today
    codes_today = db.execute("SELECT DISTINCT code FROM daily_kline WHERE date=?", (today_str,)).fetchall()
    for (code,) in codes_today:
        rows = db.execute("SELECT date, volume FROM daily_kline WHERE code=? ORDER BY date", (code,)).fetchall()
        for i in range(5, len(rows)):
            if rows[i][0] == today_str:
                prev5 = sum(rows[j][1] for j in range(i-5, i)) / 5
                if prev5 > 0:
                    db.execute("UPDATE daily_kline SET volume_ratio=? WHERE code=? AND date=?",
                              (round(rows[i][1]/prev5, 2), code, today_str))
    
    db.commit()
    db.close()
    
    final = db_count('daily_kline', today_str)
    log(f"  Step1: 完成，今日K线 {final} 条")
    return final

# ═══════════════════════════ Step2: 今日涨停池 ═══════════════════════════
def save_today_zt(today_str):
    """拉取今日涨停池入库"""
    existing = db_count('first_boards', today_str)
    if existing > 0:
        log(f"  Step2: first_boards 今日已有 {existing} 条，跳过")
        return existing
    
    log(f"  Step2: 拉取今日涨停池...")
    try:
        zt = ak.stock_zt_pool_em(date=today_str)
    except:
        log(f"  ⚠️ akshare拉取失败（可能数据未更新），稍后重试")
        return 0
    
    if len(zt) == 0:
        log(f"  ⚠️ 今日暂无涨停数据")
        return 0
    
    db = sqlite3.connect(DB)
    for _, row in zt.iterrows():
        code = str(row['代码']).zfill(6)
        seal_money = row.get('封板资金', 0) or 0
        db.execute("""
            INSERT OR REPLACE INTO first_boards 
            (date, code, name, pct, close, amount, total_cap, float_cap,
             turnover, seal_time, last_seal, bomb_count, stat, industry, seal_money)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            today_str, code, row['名称'],
            row.get('涨跌幅'), row.get('最新价'), row.get('成交额'),
            row.get('总市值'), row.get('流通市值'), row.get('换手率'),
            row.get('首次封板时间'), row.get('最后封板时间'),
            row.get('炸板次数'), row.get('涨停统计'), row.get('所属行业'),
            seal_money
        ))
    db.commit()
    db.close()
    log(f"  Step2: 入库 {len(zt)} 条")
    return len(zt)

# ═══════════════════════════ Step3: 大盘指数 ═══════════════════════════
def save_market_index(today_str):
    """拉取上证指数+深证成指"""
    existing = db_count('market_index', today_str)
    if existing >= 2:
        log(f"  Step3: market_index 已有 {existing} 条，跳过")
        return existing
    
    log(f"  Step3: 拉取大盘指数...")
    indices = {'000001': '上证指数', '399001': '深证成指'}
    saved = 0
    
    for code, name in indices.items():
        sid = f"{'sh' if code.startswith('0') else 'sz'}{code}"
        try:
            resp = requests.get(f'https://hq.sinajs.cn/list={sid}',
                              headers={'Referer': 'https://finance.sina.com.cn'}, timeout=5)
            d = resp.text.split('"')[1].split(',')
            if len(d) < 6:
                continue
            open_p, prev, price, high, low = float(d[1]), float(d[2]), float(d[3]), float(d[4]), float(d[5])
            volume, amount = float(d[8]), float(d[9])
            pct = (price - prev) / prev * 100
            
            db = sqlite3.connect(DB)
            db.execute("""
                INSERT OR IGNORE INTO market_index 
                (date, code, name, open, close, high, low, pct, volume, amount)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (today_str, code, name, open_p, price, high, low, round(pct,2), volume, amount))
            db.commit()
            db.close()
            saved += 1
        except Exception as e:
            log(f"    {code} {name}: {e}")
        time.sleep(0.2)
    
    log(f"  Step3: 入库 {saved} 条")
    return saved

# ═══════════════════════════ Step4: 更新筛选收盘 ═══════════════════════════
def update_daily_screen_close(today_str):
    """更新 daily_screen 中推送股的收盘数据 (K线优先, 缺失则 Sina API)"""
    db = sqlite3.connect(DB)
    
    # 从 auction_snapshots 取竞价数据，从 daily_kline 取收盘
    # ⚠️ k.pct 是同花顺多日累计涨跌，不可用！必须用 (close-prev)/prev 算单日
    rows = db.execute("""
        SELECT ds.code, ds.name, a.prev_close, k.close, k.high, k.low
        FROM daily_screen ds
        LEFT JOIN auction_snapshots a ON a.date = ds.screen_date AND a.code = ds.code
        LEFT JOIN daily_kline k ON k.date = ds.screen_date AND k.code = ds.code
        WHERE ds.screen_date = ? AND ds.pushed = 1
    """, (today_str,)).fetchall()
    
    if not rows:
        db.close()
        log(f"  Step4: 无推送记录")
        return 0
    
    updated = 0
    for code, name, prev, close, high, low in rows:
        # K线缺失 → 从 Sina 补拉
        if close is None:
            sid = f"{'sh' if code.startswith('6') else 'sz'}{code}"
            try:
                resp = requests.get(f'https://hq.sinajs.cn/list={sid}',
                                  headers={'Referer': 'https://finance.sina.com.cn'}, timeout=5)
                d = resp.text.split('"')[1].split(',')
                if len(d) >= 6:
                    close = float(d[3])  # 现价(收盘后即为收盘价)
                    high = float(d[4])
                    low = float(d[5])
            except:
                pass
            time.sleep(0.2)
        
        if close is None:
            continue
        
        # ✅ 统一算法: 单日涨跌 = (收盘-昨收)/昨收，永远不用 k.pct
        pct = round((close - prev) / prev * 100, 2) if prev and prev > 0 else None
        is_lu = 1 if (pct and pct >= 9.8) else 0
        
        db.execute("""
            UPDATE daily_screen 
            SET next_close = ?, next_pct = ?, next_is_lu = ?
            WHERE screen_date = ? AND code = ?
        """, (close, pct, is_lu, today_str, code))
        log(f"  {code} {name}: 收盘{close} ({pct:+.1f}%) {'🔴涨停' if is_lu else '—'}")
        updated += 1
    
    db.commit()
    db.close()
    log(f"  Step4: 更新 {updated} 条收盘数据")
    return updated

# ═══════════════════════════ Step5: 复盘汇总 ═══════════════════════════
def generate_review(today_str, yesterday_str):
    """生成复盘汇总 → daily_review + 输出"""
    db = sqlite3.connect(DB)
    
    # 首板数
    total_fb = db_count('first_boards', yesterday_str)
    
    # 今日筛选统计
    r = db.execute("""
        SELECT COUNT(*), SUM(pushed), SUM(next_is_lu)
        FROM daily_screen WHERE screen_date = ?
    """, (today_str,)).fetchone()
    candidates, pushed, hits = r[0] or 0, r[1] or 0, r[2] or 0
    
    # 大盘
    r = db.execute("""
        SELECT pct FROM market_index WHERE date=? AND code='000001'
    """, (today_str,)).fetchone()
    market_pct = r[0] if r else None
    
    if market_pct is not None:
        trend = '上涨' if market_pct > 0.5 else ('下跌' if market_pct < -0.5 else '震荡')
    else:
        trend = '?'
    
    hit_rate = round(hits/pushed*100, 1) if pushed > 0 else 0
    
    # 最佳
    r = db.execute("""
        SELECT code, name, next_gap FROM daily_screen 
        WHERE screen_date=? AND pushed=1 AND next_is_lu=1 
        ORDER BY next_gap DESC LIMIT 1
    """, (today_str,)).fetchone()
    best_code, best_name, best_gap = r if r else (None, None, None)
    
    # 入库 daily_review
    db.execute("""
        INSERT OR REPLACE INTO daily_review
        (review_date, total_first_boards, candidates_filtered, pushed,
         hit_limit_up, hit_rate, market_pct, market_trend, best_code, best_gap, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (today_str, total_fb, candidates, pushed, hits, hit_rate, 
          market_pct, trend, f"{best_code} {best_name}" if best_code else None, best_gap,
          '推送股=max5, 竞价Gap用Sina实时数据'))
    
    # 推送股详情 (在 close 前查询)
    pushed_detail = db.execute("""
        SELECT code, name, next_gap, next_close, next_pct, next_is_lu
        FROM daily_screen WHERE screen_date=? AND pushed=1
        ORDER BY next_gap DESC
    """, (today_str,)).fetchall()
    
    db.commit()
    db.close()
    
    # 输出
    log(f"\n{'='*50}")
    log(f"📊 寻龙诀 · {today_str} 复盘")
    log(f"{'='*50}")
    log(f"昨日首板: {total_fb}  候选: {candidates}  推送: {pushed}  涨停: {hits}")
    log(f"命中率: {hit_rate}%  大盘: {market_pct:+.1f}% ({trend})" if market_pct else f"命中率: {hit_rate}%")
    if best_code:
        log(f"最佳: {best_code} {best_name} Gap={best_gap:+.2f}%")
    
    if pushed_detail:
        log(f"\n推送股收盘:")
        for r in pushed_detail:
            lu = '🔴涨停' if r[5] else ('💥炸板' if r[4] and r[4] < 0 else '—')
            log(f"  {r[0]} {r[1]} Gap={r[2]:+.2f}% 收盘{r[3]} ({r[4]:+.1f}%) {lu}")

# ═══════════════════════════ Main ═══════════════════════════
def main():
    ensure_tables()
    
    today = datetime.now()
    today_str = today.strftime('%Y%m%d')
    
    weekday = today.weekday()
    if weekday >= 5:
        log("周末不交易")
        return
    
    # 确定昨日
    if weekday == 0:
        yesterday = today - timedelta(3)
    else:
        yesterday = today - timedelta(1)
    y_str = yesterday.strftime('%Y%m%d')
    
    log(f"🐉 寻龙诀 · 收盘复盘")
    log(f"今日: {today_str}  昨日首板: {y_str}")
    log("═" * 50)
    
    # Step1: 补今日K线
    db = sqlite3.connect(DB)
    codes = [r[0] for r in db.execute(
        "SELECT DISTINCT code FROM first_boards WHERE date=?", (y_str,)
    ).fetchall()]
    if not codes:
        codes = [r[0] for r in db.execute(
            "SELECT DISTINCT code FROM daily_screen WHERE screen_date=?", (today_str,)
        ).fetchall()]
    db.close()
    
    ensure_today_kline(today_str, codes)
    
    # Step2: 今日涨停池
    save_today_zt(today_str)
    
    # Step3: 大盘指数
    save_market_index(today_str)
    
    # Step4: 更新筛选收盘
    update_daily_screen_close(today_str)
    
    # Step5: 复盘汇总
    generate_review(today_str, y_str)
    
    # 汇总
    log(f"\n📊 入库汇总:")
    log(f"  daily_kline 今日: {db_count('daily_kline', today_str)} 条")
    log(f"  first_boards 今日: {db_count('first_boards', today_str)} 条")
    log(f"  market_index 今日: {db_count('market_index', today_str)} 条")
    log(f"  daily_review 汇总: {db_count('daily_review', today_str, 'review_date')} 条")

if __name__ == '__main__':
    main()
