---
name: xunlongjue
description: "寻龙诀V4.1：A股一进二竞价量化系统，8月回测58%有效胜率，全自动Cron推送。一键部署。"
version: 4.1.0
author: 寻龙诀团队
tags: [a-share, stock, 涨停, 一进二, 量化, screener, deploy]
---

# 寻龙诀 v4.1 — A股一进二竞价量化系统

8个月2128首板回测优化定版。竞价Gap为主因子，每日≤3只精选推送。

## 📦 部署（给朋友）

### 前置条件
- Hermes Agent 已安装
- Python 3.8+, pip
- 服务器需能访问新浪、同花顺 API

### 一键部署
```
# 1. 安装依赖
pip install akshare requests

# 2. 复制脚本到 ~/.hermes/scripts/
cp scripts/*.py ~/.hermes/scripts/

# 3. 初始化数据库
python3 scripts/init_db.py

# 4. 设置Cron（工作日自动运行）
hermes cron add --name "寻龙诀早盘" --schedule "26 1 * * 1-5" \
  --script morning_push.py --no-agent
hermes cron add --name "寻龙诀复盘" --schedule "30 7 * * 1-5" \
  --script afternoon_review.py --no-agent
hermes cron add --name "大盘预测" --schedule "20 7 * * 1-5" \
  --script market_signal.py --no-agent
```

## ⚙️ V4.1 策略参数

| 条件 | 阈值 | 说明 |
|------|:--:|------|
| 竞价Gap | >5.5% | 核心因子，单调递增 |
| 量比 | >0.3 | 缩量涨停最优 |
| 股价 | <50 | — |
| 首板振幅 | <12% | 振幅过大=分歧大 |
| 封板时间 | ≤13:10 | — |
| 市值 | 45~200亿 | — |
| 成交额 | >1.5亿 | — |
| 首板开盘 | <5% | — |
| 流通市值 | >43亿 | — |
| 二板一字板 | 排除 | T字板可接受 |

### 推送规则
- 每日 ≤3只（按软排得分Top3）
- 每周 ≥5只
- 一条合并消息推送（防微信限流）

## 📊 回测成绩

| 指标 | 数值 |
|------|:--:|
| 8月全期有效胜率 | 58.0% |
| 近3月有效胜率 | 69.8% |
| 周均推送 | 7.7只 |
| 最佳月 | 12月/4月 71% |
| 样本量 | 2128首板 |

## 🔧 数据源

| 数据 | API | 状态 |
|------|-----|:--:|
| 涨停池 | akshare stock_zt_pool_em | ✅ |
| 历史K线 | 同花顺 d.10jqka.com.cn | ✅ |
| 实时竞价 | 新浪 hq.sinajs.cn | ✅ |
| 东方财富 | push2.eastmoney.com | ❌ 已封 |

## ⚠️ 关键踩坑

1. **同花顺pct是累计**: `daily_kline.pct` 是~140天累计涨跌，绝不用于单日计算
2. **微信限流**: 单条合并推送，cron间隔>1分钟
3. **先查后拉**: 所有数据先查库，缺才拉API，不重复拉取
4. **周末陷阱**: 周五首板→次交易日是周一
5. **东方财富API**: 本服务器已被封，不要使用

## 📁 文件结构

```
scripts/
  morning_push.py      — 早盘选股主脚本
  afternoon_review.py  — 收盘复盘脚本
  market_signal.py     — 大盘预测脚本
  hermes_stock_lib.py  — 共享函数库
  init_db.py           — 数据库初始化
references/
  database-schema.md   — 数据库表结构
  pitfalls.md          — 完整踩坑记录
```
